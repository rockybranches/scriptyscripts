# scriptyscripts

*CLI interface for running custom scripts*

## Author

Robbie Capps, 2023


