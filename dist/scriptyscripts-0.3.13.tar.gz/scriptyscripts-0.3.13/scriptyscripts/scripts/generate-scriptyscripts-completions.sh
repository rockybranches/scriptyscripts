#!/bin/sh

export DEFAULT_SSCRIPTS_SHELL="${SHELL##*/}"
export SSCRIPTS_SHELL=${SSCRIPTS_SHELL:-$DEFAULT_SSCRIPTS_SHELL}
export _SCRIPTYSCRIPTS_COMPLETE="${SSCRIPTS_SHELL}_source scriptyscripts"
export _SSCRIPTS_COMPLETE="${SSCRIPTS_SHELL}_source sscripts"

_generate_completion_script() {
    _SCRIPTYSCRIPTS_COMPLETE=${SSCRIPTS_SHELL}_source scriptyscripts >~/.scriptyscripts-completion.${SSCRIPTS_SHELL}
    _SSCRIPTS_COMPLETE=${SSCRIPTS_SHELL}_source sscripts >~/.sscripts-completion.${SSCRIPTS_SHELL}
}

_add_scriptyscripts_completion() {
    _com_cmd='\n\n# scriptyscripts completion\neval "$(_SCRIPTYSCRIPTS_COMPLETE='${SSCRIPTS_SHELL}'_source scriptyscripts)"\neval "$(_SSCRIPTS_COMPLETE='${SSCRIPTS_SHELL}'_source sscripts)"\n\n'
    if [ -f ~/.extend.${SSCRIPTS_SHELL}rc ]; then
        if ! grep -q "$_com_cmd" ~/.extend.${SSCRIPTS_SHELL}rc; then
            echo -e "$_com_cmd" >>~/.extend.${SSCRIPTS_SHELL}rc
        fi
    else
        if [ -f ~/.${SSCRIPTS_SHELL}rc ]; then
            if ! grep -q "$_com_cmd" ~/.${SSCRIPTS_SHELL}rc; then
                echo "$_com_cmd" >>~/.${SSCRIPTS_SHELL}rc
            fi
        fi
    fi
}
