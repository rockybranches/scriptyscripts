import shlex
import itertools
import click
import os
import sys
from pathlib import Path
from difflib import get_close_matches
import subprocess
from typing import List
import importlib
import pfun_path_helper as pph

pph.append_path()

#: import interactive_pager
interactive_pager = importlib.import_module(
    ".tools.interactive_pager",
    package="scriptyscripts"
).interactive_pager


#: path to ~/scriptyscripts
pth = Path(os.getenv("HOME")).joinpath("scriptyscripts")


def get_version_from_poetry():
    output = subprocess.run(
        ['poetry', 'version', '--short'],
        check=True, text=True, capture_output=True
    )
    if output is None or len(output) == 0:
        raise RuntimeError("Failed to get version from poetry.")
    return output.stdout.strip()


@click.version_option()
@click.group()
@click.pass_context
def cli(ctx):
    if not ctx.obj:
        ctx.obj = ctx.ensure_object(dict)
    return ctx


@cli.command("version")
def print_version():
    """Print the version of scriptyscripts."""
    click.secho(get_version_from_poetry(), color='success', bold=True)


@cli.command("path")
def print_path():
    """print the scriptyscriptys path (should be ~/scriptyscripts)."""
    click.secho(str(pth.absolute().resolve()))


def get_matches(ctx, param, value, n=1, cutoff=0.1) -> List[str]:
    command = value
    results = search_scriptyscripts(ctx, None, '*')
    if n <= 0:
        n = len(results)
    matches = get_close_matches(command, results, n=n, cutoff=cutoff)
    if isinstance(matches, str):
        matches = [matches, ]
    n_matches = len(matches)
    ctx.obj['n_matches'] = n_matches
    match n_matches:
        case 0:
            # error for zero results
            click.secho(f"No scriptyscripts command matching '{
                        command}' was found.", err=True)
            exit(1)
        case 1:
            #: handle a single result (always return a List[str])
            return [matches[0], ]
        case _:
            # handle more than 1 result
            return matches


def generate_pager_results(results, interactive=True):
    """utilizes an (non-)interactive pager"""
    match interactive:
        case True:
            # flush stdout and stderr before running pager
            sys.stdout.flush()
            sys.stderr.flush()
            selection = interactive_pager(results)
            sys.stdout.flush()
            sys.stderr.flush()
            click.secho(
                selection, color='success', blink=False, bold=True
            )
            sys.stdout.flush()
            sys.stderr.flush()
            return selection
        case False:
            # flush stdout and stderr before printing results
            sys.stdout.flush()
            sys.stderr.flush()
            output = "\n".join([result.strip() for result in results])
            click.secho(output, color='green')
            sys.stdout.flush()
            sys.stderr.flush()
            separator = "=" * 10
            click.secho(
                f"\n\n{
                    separator}\n\nClosest match:\n\n\t{results[-1]}\n\n",
                color='success', bold=True, blink=False
            )
            sys.stdout.flush()
            sys.stderr.flush()
            return output


def search_scriptyscripts(ctx, param, value, n=-1, cutoff=0.1):
    """Search for scriptyscripts commands."""

    @click.pass_context
    def update_context(ctx, param, value):
        if not ctx.obj:
            ctx.obj = ctx.ensure_object(dict)
        if hasattr(param, 'name'):
            ctx.obj[f'_orig.{param.name}'] = value
        return ctx

    n = ctx.params.get('n', n)

    if len(value) == 0:
        value = "*"
    else:
        value = "".join(value)

    ctx = update_context(param, value)

    results = pth.glob(value)

    #: exclude emacs backup files
    results = [str(r) for r in itertools.filterfalse(
        lambda r: str(r)[-1] == '~', results)]

    #: handle no results
    if len(results) == 0:
        results = get_matches(ctx, param, value, n=n, cutoff=cutoff)
    return results


@cli.command("list")
@click.argument("glob_pattern", nargs=-1, callback=search_scriptyscripts)
@click.option("-n", "--n", "--N", default=10, help="Maximum number of results to show")
@click.option("--pager/--no-pager", is_flag=True, default=False,
              help="Whether or not to use a pager to display results")
@click.pass_context
def list_commands(ctx, glob_pattern, n, pager):
    """List the commands in ~/scriptyscripts matching GLOB_PATTERN.

    GLOB_PATTERN is a regex-like search pattern, e.g. 'test-*'.
    """
    click.secho(
        "\nMatching scriptyscripts commands:",
        color='success', bold=True, blink=False)
    results = [g.strip() for g in reversed(glob_pattern)]  # ! after callback
    nresults = ctx.obj.get('n_matches', len(results))
    if nresults > n:
        results = results[:n]
    match nresults:
        case 0:
            click.secho("failed to find any matching commands!", err=1)
            exit(1)
        case 1:
            click.secho(results[0], color='success', bold=True)
        case _:
            generate_pager_results(results, interactive=pager)
    return True


def search_scriptyscripts_run(ctx, param, value, n=5, cutoff=0.1):
    return search_scriptyscripts(ctx, param, value, n=n, cutoff=cutoff)


def handle_results(ctx, results, interactive=True):
    """handle results depending on number of results (n_matches)"""
    nresults = ctx.obj.get('n_matches', len(results))
    match nresults:
        case 0:
            raise RuntimeError("No matching scriptyscripts command was found.")
        case 1:
            command = results[0]
        case _:
            # handle results interactively
            command = generate_pager_results(results, interactive=interactive)
    return command


@cli.command(context_settings=dict(
    ignore_unknown_options=True,
))
@click.argument("command", nargs=1, required=True, type=click.UNPROCESSED,
                callback=search_scriptyscripts_run)
@click.argument("args", nargs=-1, required=False, type=click.UNPROCESSED)
@click.pass_context
def run(ctx, command, args):
    """"
    Execute the given COMMAND (should match something in the ~/scriptyscripts directory).

    COMMAND given command in the ~/scriptyscripts directory.
    ARGS arguments for the given command (if needed).
    """
    # handle results after running search...
    results = [c for c in command] if not isinstance(command, str) \
        else [command, ]
    command = handle_results(ctx, results, interactive=True)

    # handle missing args
    if args is None:
        args = []

    # execute command
    subprocess.run(shlex.split(command) + [a for a in args], check=True)


@cli.command()
@click.argument("command", nargs=1, required=False, type=click.types.StringParamType(),
                callback=search_scriptyscripts_run)
@click.pass_context
def edit(ctx, command):
    """Edit the specified command in emacs.

    COMMAND given command in the ~/scriptyscripts directory.

    ...otherwise opens emacs in the ~/scriptyscripts directory.
    """
    if command is None:
        command = '~/scriptyscripts'
    results = [c for c in command] if not isinstance(command, str) \
        else [command, ]
    # handle results interactively
    command = handle_results(ctx, results, interactive=True)

    import time
    click.secho(f"Opening {command} in emacs...", color='success', bold=True)
    time.sleep(1)
    # countdown indicator
    for i in range(3, 0, -1):
        click.secho(f"Opening {command} in emacs in {
                    i} seconds...", color='success', bold=True)
        time.sleep(1)
    subprocess.run(['subl', command], check=True)


@cli.command()
@click.option(
    "--bump/--no-bump", is_flag=True, default=True, help="Bump version"
)
@click.option(
    "--version",
    help="Set version",
    type=click.types.Choice(
        ['major', 'minor', 'patch', 'prepatch', 'preminor', 'premajor']),
    default='patch'
)
@click.option(
    "--backup/--no-backup",
    is_flag=True,
    default=True,
    help="Backup to remote git repo"
)
def upgrade(bump, version, backup):
    """Update scriptyscripts to the local HEAD."""
    click.secho("Upgrading scriptyscripts...", color='success', bold=True)
    # get the working directory for the scriptyscripts installation
    shell_cwd = Path(__file__).parent.joinpath('..').absolute()
    # bump the version
    if bump:
        subprocess.run(
            ['poetry', 'version', f'{version}'], check=True, cwd=shell_cwd)
    # install the new version
    subprocess.run(["poetry", "install"], check=True, cwd=shell_cwd)
    # upgrade in pipx
    subprocess.run(["pipx", "upgrade", "scriptyscripts"], check=True)
    # backup to remote git repo
    if backup:
        subprocess.run(['sh', '-c', 'backup-rcapps-config'], check=True)
    click.secho("Upgrade complete!", color='success', bold=True)


@cli.command("link")
def link_scripts():
    """Link config & scripts locally."""
    click.secho("Linking config & scripts...", color='success', bold=True)
    subprocess.run(['sh', '-c', 'link_scripts'], check=True)
    click.secho("Linking complete!", color='success', bold=True)


@cli.command("completions")
@click.option("--shell", type=click.types.Choice(['zsh', 'bash']),
              default='zsh', help="Shell to generate completions for")
def completions(shell):
    """Generate shell completions for scriptyscripts."""
    click.secho("Generating shell completions for scriptyscripts...",
                color='success', bold=True)
    completions_funcs_path = os.path.join(
        os.path.dirname(__file__),
        'scripts', 'generate-scriptyscripts-completions.sh'
    )
    user_response = click.prompt(
        "This will modify your shell's startup file (e.g. .zshrc or .bashrc).\n"
        "Would you like to continue?",
        type=click.types.Choice(['yes', 'no']),
        default='yes'
    )
    if user_response == 'no':
        click.secho("Exiting without generating completions...",
                    color='success', bold=True)
        exit(0)
    subprocess.run([
        f'{shell}', '-c', f'''
        source {completions_funcs_path} && \
            _generate_completion_script_{shell} && \
                _add_scriptyscripts_completion_{shell}rc'''],
        check=True
    )
    click.secho(
        ("Completions generation for scriptyscripts complete!\n"
         "Reload your shell to use the completions."),
        color='success',
        bold=True
    )


if __name__ == '__main__':
    cli()
