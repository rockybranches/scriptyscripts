#!/bin/sh

_generate_completion_script_zsh() {
    _SCRIPTYSCRIPTS_COMPLETE=zsh_source scriptyscripts >~/.scriptyscripts-completion.zsh
}

_add_scriptyscripts_completion_zshrc() {
    _com_cmd='\n\n# scriptyscripts completion\neval "$(_SCRIPTYSCRIPTS_COMPLETE=zsh_source scriptyscripts)"\n\n'
    if [[ -f ~/.extend.zshrc && ! $(grep -q "$_com_cmd" ~/.extend.zshrc) ]]; then
        echo -e "$_com_cmd" >>~/.extend.zshrc
    else
        if [[ -f ~/.zshrc && ! $(grep -q "$_com_cmd" ~/.zshrc) ]]; then
            echo -e "$_com_cmd" >>~/.zshrc
        fi
    fi
}

_generate_completion_script_bash() {
    _SCRIPTYSCRIPTS_COMPLETE=bash_source scriptyscripts >~/.scriptyscripts-completion.bash
}

_add_scriptyscripts_completion_bashrc() {
    _com_cmd='\n\n# scriptyscripts completion\neval "$(_SCRIPTYSCRIPTS_COMPLETE=bash_source scriptyscripts)"\n\n'
    if [[ -f ~/.extend.bashrc && ! $(grep -q "$_com_cmd" ~/.extend.bashrc) ]]; then
        echo -e "$_com_cmd" >>~/.extend.bashrc
    fi
}

